/*Build a query that retrieves the appointment data, focusing on patient arrival times and when the patient
was admitted across different departments*/

