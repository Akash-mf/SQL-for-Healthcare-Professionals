--CHALLENGE: Find out the distribution of appointments across each day in the hospital

