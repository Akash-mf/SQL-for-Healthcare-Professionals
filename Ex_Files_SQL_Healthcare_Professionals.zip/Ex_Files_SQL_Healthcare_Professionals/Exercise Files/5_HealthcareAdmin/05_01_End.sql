/*Build a query that retrieves the appointment data, focusing on patient arrival times and when the patient
was admitted across different departments*/

SELECT
department_name,
AVG(DATEDIFF(minute, arrival_time, admission_time)) AS avg_wait_time,
MIN(DATEDIFF(minute, arrival_time, admission_time)) AS min_waiting_time,
MAX(DATEDIFF(minute, arrival_time, admission_time)) AS max_waiting_time,
COUNT(*) AS total_appointments
FROM [Healthcare_Database].[dbo].Appointments
GROUP BY department_name