--CHALLENGE: Find out the distribution of appointments across each day in the hospital

SELECT
DATENAME(weekday, appointment_date) AS weekday,
COUNT(*) AS appointment_count
FROM [Healthcare_Database].[dbo].Appointments
GROUP BY DATENAME(weekday, appointment_date)
ORDER BY appointment_count DESC