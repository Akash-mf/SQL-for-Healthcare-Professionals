--Identify the readmission rates per department

--Show the profile of the patients being readmitted