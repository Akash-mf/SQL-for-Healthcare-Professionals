--Build a query to ensure the patients are getting their lab tests done on the same day as their visit

SELECT
ov.visit_id,
ov.visit_date,
ov.doctor_name,
lr.test_name,
lr.test_date,
DATEDIFF(day, ov.visit_date, lr.test_date) AS days_between_visit_and_test
FROM
[Healthcare_Database].[dbo].[Outpatient Visits] AS ov
INNER JOIN [Healthcare_Database].[dbo].[Lab Results] AS lr
ON ov.visit_id = lr.visit_id