--Identify the readmission rates per department

SELECT
department_name,
COUNT(patient_id) AS total_patients,
COUNT(CASE WHEN days_in_the_hospital > 1 THEN patient_id END) AS readmitted_patients,
(COUNT(CASE WHEN days_in_the_hospital > 1 THEN patient_id END) *100.0)/COUNT(patient_id) AS readmission_rate
FROM [Healthcare_Database].[dbo].[Hospital Records]
GROUP BY department_name

--Show the profile of the patients being readmitted

SELECT
department_name,
gender,
AVG(bmi) AS avg_bmi,
COUNT(p.patient_id) AS total_patients,
AVG(DATEDIFF(year, date_of_birth, GETDATE())) AS avg_age,
COUNT(CASE WHEN days_in_the_hospital > 1 THEN p.patient_id END) AS readmitted_patients,
(COUNT(CASE WHEN days_in_the_hospital > 1 THEN p.patient_id END) *100.0)/COUNT(p.patient_id) AS readmission_rate
FROM [Healthcare_Database].[dbo].[Hospital Records] AS hr
INNER JOIN [Healthcare_Database].[dbo].Patients AS p
ON hr.patient_id = p.patient_id
GROUP BY department_name,
gender