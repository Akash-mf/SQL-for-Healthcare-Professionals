/* Assess how many patients are considered High, Medium, and Low Risk.

High Risk: patients who are smokers and have been diagnosed with either hypertension or diabetes
Medium Risk: patients who are non-smokers and have been diagnosed with either hypertension or diabetes
Low Risk: patients who do not fall into the High or Medium Risk categories. This includes patients who are not
smokers and do not have a diagnosis of hypertension or diabetes*/