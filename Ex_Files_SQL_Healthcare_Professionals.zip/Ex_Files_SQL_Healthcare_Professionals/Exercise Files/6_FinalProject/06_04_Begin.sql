/*What are the most common appointment times throughout the day, and how does the distribution of apppointment
times vary across different hours?*/