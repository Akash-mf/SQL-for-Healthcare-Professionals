/*SOLUTION: Identify individuals at high risk of developing diabetes within a population based on smoker
status and glucose levels

- Individuals who are smokers and have glucose level more or equal to 126 are considered at High Risk
- Individuals who are smokers and have glucose level more or equal to 100, but less than 126 are considered 
  at Medium Risk
- Everyone else is Low Risk*/


SELECT
CASE
WHEN smoker_status = 'Y' OR result_value >= 126 THEN 'High Risk for Diabetes'
WHEN smoker_status = 'Y' OR (result_value >=100 AND result_value <126) THEN 'Medium Risk for Diabetes'
ELSE 'Low Risk for Diabetes'
END AS risk_category,
COUNT(*) AS population_count
FROM
[Healthcare_Database].[dbo].[Outpatient Visits] AS ov
INNER JOIN [Healthcare_Database].[dbo].[Lab Results] AS lr
ON ov.visit_id = lr.visit_id
WHERE test_name = 'fasting blood sugar'
GROUP BY
CASE
WHEN smoker_status = 'Y' OR result_value >= 126 THEN 'High Risk for Diabetes'
WHEN smoker_status = 'Y' OR (result_value >=100 AND result_value <126) THEN 'Medium Risk for Diabetes'
ELSE 'Low Risk for Diabetes'
END
