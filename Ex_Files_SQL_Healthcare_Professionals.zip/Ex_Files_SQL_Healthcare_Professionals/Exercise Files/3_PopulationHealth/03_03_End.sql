/*Create a series of CASE statements to predict the likelihood of hypertension development based on
patient's age, BMI and family history of hypertension

Exclude children from this model*/

SELECT
p.patient_id,
p.patient_name,
CASE
WHEN family_history_of_hypertension = 'Yes' THEN 1
WHEN family_history_of_hypertension = 'No' THEN 0
END AS family_history_of_hypertension,
CASE
WHEN BMI < 18.5 THEN 'Underweight'
WHEN BMI >= 18.5 AND BMI < 25 THEN 'Normal'
WHEN BMI >= 25 AND BMI <30 THEN 'Overweight'
ELSE 'Obese'
END AS bmi_category,
CASE
WHEN DATEDIFF(year, date_of_birth, getdate()) >= 50 THEN 1
ELSE 0
END AS age_over_50,
CASE
WHEN (family_history_of_hypertension = 'Yes' OR DATEDIFF(year, date_of_birth, getdate()) >= 50) AND BMI >=30
THEN 'High Risk'
WHEN (family_history_of_hypertension = 'Yes' OR DATEDIFF(year, date_of_birth, getdate()) >= 50) AND BMI >=25
AND BMI <30 THEN 'Medium Risk'
ELSE 'Low Risk'
END hypertension_prediction
FROM 
[Healthcare_Database].[dbo].Patients AS p
INNER JOIN [Healthcare_Database].[dbo].[Hospital Records] AS hr
ON p.patient_id = hr.patient_id
WHERE DATEDIFF(year, date_of_birth, getdate()) >= 18

