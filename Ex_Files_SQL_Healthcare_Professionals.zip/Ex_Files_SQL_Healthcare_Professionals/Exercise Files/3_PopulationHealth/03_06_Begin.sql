/*CHALLENGE: Identify individuals at high risk of developing diabetes within a population based on smoker
status and glucose levels

- Individuals who are smokers and have glucose level more or equal to 126 are considered at High Risk
- Individuals who are smokers and have glucose level more or equal to 100, but less than 126 are considered 
  at Medium Risk
- Everyone else is Low Risk*/

