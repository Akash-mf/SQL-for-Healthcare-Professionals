/*Create a series of CASE statements to predict the likelihood of hypertension development based on
patient's age, BMI and family history of hypertension

Exclude children from this model*/

