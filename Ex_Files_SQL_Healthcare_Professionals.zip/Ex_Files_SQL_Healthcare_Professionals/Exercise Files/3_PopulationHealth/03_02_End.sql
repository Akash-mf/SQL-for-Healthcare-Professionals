--Classify patients into high, medium or low risk based on their BMI and family risk of hypertension

SELECT
patient_id,
patient_name,
bmi,
family_history_of_hypertension,
CASE
WHEN bmi >= 30 AND family_history_of_hypertension = 'Yes' THEN 'High Risk'
WHEN bmi >= 25 AND family_history_of_hypertension = 'Yes' THEN 'Medium Risk'
ELSE 'Low Risk'
END risk_category
FROM [Healthcare_Database].[dbo].[Hospital Records]