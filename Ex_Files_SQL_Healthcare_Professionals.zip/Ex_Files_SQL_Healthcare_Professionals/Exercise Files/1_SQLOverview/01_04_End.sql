--Categorize patients based on their length of stay in the hospital

SELECT
patient_id,
days_in_the_hospital,
CASE
WHEN days_in_the_hospital <=3 THEN 'Short'
WHEN days_in_the_hospital <= 5 THEN 'Medium'
ELSE 'Long'
END AS stay_category
FROM [Healthcare_Database].[dbo].[Hospital Records]

--Count the number of patients in each category created

SELECT
CASE
WHEN days_in_the_hospital <=3 THEN 'Short'
WHEN days_in_the_hospital <= 5 THEN 'Medium'
ELSE 'Long'
END AS stay_category,
COUNT(*) AS number_of_records
FROM [Healthcare_Database].[dbo].[Hospital Records]
GROUP BY
CASE
WHEN days_in_the_hospital <=3 THEN 'Short'
WHEN days_in_the_hospital <= 5 THEN 'Medium'
ELSE 'Long'
END


