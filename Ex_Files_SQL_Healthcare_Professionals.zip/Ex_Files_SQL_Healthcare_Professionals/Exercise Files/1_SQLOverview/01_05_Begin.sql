--Getting the current date and time

--Extract the day of the week from the "appointment_date" column in integer

--Extract the hour from the "appointment_time" column

--Extract the day of the week from the "appointment_date" column in character strings

--Add five days to a date

--Subtract two months from a date

--Retrieve the amount of days between January 1st 2024 and January 10th 2024

--Retrieve the number of months between January 1st 2023 and May 10th 2024

--Calculate the difference between the arrival time and appointment time in hours

