--Find all the patient's records in the appointments table

--Find the patient ID of patients who had an appointment in the pediatrics department
