--Which patients on the "patients" table were hospitalized and for how many days

--Verify who has a hospital record