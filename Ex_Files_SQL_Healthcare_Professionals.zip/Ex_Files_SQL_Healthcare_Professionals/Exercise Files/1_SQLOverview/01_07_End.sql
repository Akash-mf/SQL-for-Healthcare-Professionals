--Which patients on the "patients" table were hospitalized and for how many days

SELECT
p.patient_id,
Days_in_the_hospital
FROM
[Healthcare_Database].[dbo].[patients] AS p
INNER JOIN [Healthcare_Database].[dbo].[Hospital Records] AS hr
ON p.patient_id = hr.patient_id

--Verify who has a hospital record

SELECT
p.patient_id,
Days_in_the_hospital
FROM
[Healthcare_Database].[dbo].[patients] AS p
LEFT JOIN [Healthcare_Database].[dbo].[Hospital Records] AS hr
ON p.patient_id = hr.patient_id
WHERE Days_in_the_hospital IS NULL