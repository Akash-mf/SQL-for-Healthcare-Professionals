--Find all the patient's records in the appointments table

SELECT *
FROM [Healthcare_Database].[dbo].Appointments

--Find the patient ID of patients who had an appointment in the pediatrics department

SELECT
patient_id,
department_name
FROM [Healthcare_Database].[dbo].Appointments
WHERE department_name = 'pediatrics'