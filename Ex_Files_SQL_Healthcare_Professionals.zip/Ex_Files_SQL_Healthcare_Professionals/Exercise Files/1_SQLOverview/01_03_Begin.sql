--Find out how many days on average the patients spent in the Cardiology department of the hospital

--Compare the average number of days the patients are spending in each department of the hospital