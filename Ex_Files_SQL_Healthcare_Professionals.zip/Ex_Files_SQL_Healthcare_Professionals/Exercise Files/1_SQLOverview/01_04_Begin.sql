--Categorize patients based on their lenght of stay in the hospital

--Count the number of patients in each category created