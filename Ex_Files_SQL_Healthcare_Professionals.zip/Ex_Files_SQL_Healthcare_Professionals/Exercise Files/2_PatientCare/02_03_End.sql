--Flag patients who are at risk due to interaction between their medication and smoking status

SELECT
patient_id,
diagnosis,
medication_prescribed,
smoker_status,
CASE
WHEN smoker_status = 'Y' AND medication_prescribed IN ('Insulin', 'Metformin', 'Lisinopril')
THEN 'Potential Safety Concern: Smoking and Medication Interactions'
ELSE 'No Safety Concern Identified'
END AS 'safety_concern'
FROM [Healthcare_Database].[dbo].[Outpatient Visits]