/*Develop a query to explore the different relationships between age, gender, medication prescribed and
blood sugar control among diabetic patients who had a Fasting Blood Sugar test*/

