/*Identify a cohort of patients with chronic diseases, including hypertension, hyperlipidemia, and diabetes.
Only include patients who have visited the clinic within the last year*/


