--Examine the demographic characteristics of diabetic patients by gender and age group

SELECT
gender,
CASE
WHEN DATEDIFF(year, date_of_birth, getdate()) BETWEEN 18 AND 30 THEN '18-30'
WHEN DATEDIFF(year, date_of_birth, getdate()) BETWEEN 31 AND 50 THEN '31-50'
WHEN DATEDIFF(year, date_of_birth, getdate()) BETWEEN 51 AND 70 THEN '51-70'
ELSE '71+'
END AS age_group,
COUNT(*) AS patient_count
FROM
[Healthcare_Database].[dbo].Patients AS p
INNER JOIN [Healthcare_Database].[dbo].[Outpatient Visits] AS ov
ON p.patient_id = ov.patient_id
WHERE diagnosis = 'Diabetes'
GROUP BY
gender,
CASE
WHEN DATEDIFF(year, date_of_birth, getdate()) BETWEEN 18 AND 30 THEN '18-30'
WHEN DATEDIFF(year, date_of_birth, getdate()) BETWEEN 31 AND 50 THEN '31-50'
WHEN DATEDIFF(year, date_of_birth, getdate()) BETWEEN 51 AND 70 THEN '51-70'
ELSE '71+'
END


--Investigate the main reason for diabetic patients to visit the hospital

SELECT
reason_for_visit,
COUNT(*) AS visit_count
FROM [Healthcare_Database].[dbo].[Outpatient Visits]
WHERE diagnosis = 'Diabetes'
GROUP BY reason_for_visit
ORDER BY visit_count DESC

--Distribution of smoker status among diabetic patients by gender

SELECT
gender,
smoker_status,
COUNT(*) AS patient_count
FROM [Healthcare_Database].[dbo].[Outpatient Visits] AS ov
INNER JOIN [Healthcare_Database].[dbo].Patients AS p
ON ov.patient_id = p.patient_id
WHERE diagnosis = 'Diabetes'
GROUP BY gender, smoker_status

