--Examine the demographic characteristics of diabetic patients by gender and age group

--Investigate the main reason for diabetic patients to visit the hospital

--Distribution of smoker status among diabetic patients by gender

