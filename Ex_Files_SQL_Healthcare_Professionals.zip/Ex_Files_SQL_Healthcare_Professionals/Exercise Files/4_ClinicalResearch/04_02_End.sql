/*Identify a cohort of patients with chronic diseases, including hypertension, hyperlipidemia, and diabetes.
Only include patients who have visited the clinic within the last year*/

SELECT
patient_id,
diagnosis,
visit_date
FROM [Healthcare_Database].[dbo].[Outpatient Visits]
WHERE diagnosis IN ('Hypertension', 'Hyperlipidemia', 'Diabetes')
AND (visit_date >= DATEADD(year, -1, getdate())
AND visit_date <= getdate())
